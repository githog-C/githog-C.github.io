/* Plurk backup full-text search engine (client-side, offline, generic).
   Identity (display name / name colour / avatar), backup date and counts are
   read at runtime from the backup's own data/user.js and data/info.js, so this
   file contains no account-specific data and works with any Plurk backup.

   Clicking any result (plurk or response) opens that plurk's whole thread
   (main plurk + all responses); clicking a response auto-scrolls to it.

   Query syntax: whitespace-separated terms are ANDed; a term prefixed with
   "-" excludes records containing it.

   UI language: zh-Hant / English, switchable from the top bar. Only the
   interface is translated - backed-up content is always shown as archived. */
(function () {
  var DATA = window.SEARCH_DATA || [];
  var U = (window.BackupData && window.BackupData.user) || {};
  var INFO = (window.BackupData && window.BackupData.info) || {};

  // ---- i18n ----------------------------------------------------------------
  // Plurk's own English wording (per https://www.plurk.com/help/en/plurk and
  // /help/en/timeline): a post is a "plurk", an answer to it is a "reply",
  // and tags are "hashtags".
  var LANG_KEY = 'plurk_search_lang';
  var I18N = {
    zh: {
      html_lang: 'zh-Hant',
      app_title: 'Plurk Backup ── 全文檢索',
      lang_btn: 'EN',
      q_ph: '輸入關鍵字（以空白分隔可多詞 AND 搜尋；字首加 - 為排除）',
      btn_search: '搜尋',
      btn_clear: '清除',
      f_plurk: '噗首',
      f_resp: '回應',
      f_me: '本人',
      f_others: '他人',
      f_hashtag: 'Hashtag',
      cal_head: '年月篩選',
      cal_all: '全部期間',
      kind_p: '噗首',
      kind_r: '回應',
      badge_others: '他人',
      owner_fallback: '本人',
      tag_all: function (n) { return '全部 hashtag (' + n + ')'; },
      open_plurk: function (b) { return ' 開原噗 p/' + b; },
      more: function (s, tot) { return '載入更多（已顯示 ' + s + ' / ' + tot + '）'; },
      empty_start: '輸入關鍵字，或從左欄選擇年月，開始檢索。<br>（未設定任何條件時不顯示結果）',
      empty_none: '沒有符合條件的結果',
      stat_idle: function (tot, np, nr) {
        return '目前未設定條件 ── 全部 ' + tot + ' 筆（噗首 ' + np + '、回應 ' + nr + '）';
      },
      stat_hit: function (n, scope, tot) {
        return '符合 <b>' + n + '</b> 筆 ' + scope + '（全部 ' + tot + ' 筆）';
      },
      scope_all: '｜全範圍',
      scope_sel: function (v) { return '｜範圍 ' + v; },
      footer: function (d, np, nr, tot, tg) {
        return '備份於 <b>' + d + '</b>　｜　噗首 <b>' + np + '</b>　回應 <b>' + nr
             + '</b>　｜　索引 <b>' + tot + '</b> 筆　｜　hashtag <b>' + tg + '</b> 個';
      },
      pop_title: function (b, n) { return 'p/' + b + '　共 ' + n + ' 則回應'; },
      pop_nohead: '（此回應的噗首未在備份中）',
      pop_noresp: '此噗沒有備份到回應'
    },
    en: {
      html_lang: 'en',
      app_title: 'Plurk Backup ── Full-text Search',
      lang_btn: '中文',
      q_ph: 'Enter keywords (space-separated terms are ANDed; prefix - to exclude)',
      btn_search: 'Search',
      btn_clear: 'Clear',
      f_plurk: 'Plurks',
      f_resp: 'Replies',
      f_me: 'Me',
      f_others: 'Others',
      f_hashtag: 'Hashtag',
      cal_head: 'Year / month',
      cal_all: 'All dates',
      kind_p: 'Plurk',
      kind_r: 'Reply',
      badge_others: 'Others',
      owner_fallback: 'Me',
      tag_all: function (n) { return 'All hashtags (' + n + ')'; },
      open_plurk: function (b) { return ' Open p/' + b + ' on Plurk'; },
      more: function (s, tot) { return 'Load more (showing ' + s + ' / ' + tot + ')'; },
      empty_start: 'Enter a keyword, or pick a year / month on the left, to start searching.'
                 + '<br>(Nothing is listed until at least one condition is set.)',
      empty_none: 'No matching results',
      stat_idle: function (tot, np, nr) {
        return 'No conditions set ── ' + tot + ' records in total (plurks ' + np
             + ', replies ' + nr + ')';
      },
      stat_hit: function (n, scope, tot) {
        return '<b>' + n + '</b> matches ' + scope + ' (of ' + tot + ' records)';
      },
      scope_all: '｜ all dates',
      scope_sel: function (v) { return '｜ range ' + v; },
      footer: function (d, np, nr, tot, tg) {
        return 'Backed up on <b>' + d + '</b>　｜　plurks <b>' + np + '</b>　replies <b>' + nr
             + '</b>　｜　index <b>' + tot + '</b> records　｜　hashtags <b>' + tg + '</b>';
      },
      pop_title: function (b, n) { return 'p/' + b + '　' + n + ' replies'; },
      pop_nohead: '(The plurk this reply belongs to is not in the backup.)',
      pop_noresp: 'No replies were backed up for this plurk'
    }
  };
  var lang = 'zh';
  try {
    var saved = window.localStorage && window.localStorage.getItem(LANG_KEY);
    if (saved && I18N[saved]) lang = saved;
  } catch (e) { /* private mode: keep the default */ }
  function L() { return I18N[lang]; }

  var OWNER = {
    id: U.id,
    color: U.name_color || '',
    nick: U.nick_name || ''
  };
  var HAS_OWNER_NAME = !!(U.display_name || U.nick_name);
  function ownerName() { return U.display_name || U.nick_name || L().owner_fallback; }

  var PAGE = 200;
  var shown = 0, matched = [], terms = [], negs = [];
  var idle = true;                // true while no search condition is set
  var sel = null;                 // null | {type:'year',v} | {type:'month',v}
  var byBase = {};                // base_id -> {p: plurkRec, r: [respRecs]}
  var NP = 0, NR = 0;             // plurk / response counts
  var TAGS = [], TAGCOUNT = {};   // hashtag list + counts
  var openedThread = null;        // {bid, src} of the popup currently shown

  var $q, $stat, $results, $more, $moreBtn, $tag, $footer, $rightHolder;

  // ---- helpers ----
  function stripHtml(h) {
    return h.replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, ' ').replace(/\s+/g, ' ');
  }
  function reEsc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function comma(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtDate(s) {
    var d = new Date(s);
    return isNaN(d) ? (s || '') : d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function avatarUrl(u) {
    return u && u.id && u.avatar
      ? 'https://avatars.plurk.com/' + u.id + '-medium' + u.avatar + '.gif'
      : 'https://www.plurk.com/static/default_big.jpg';
  }

  function highlight(html) {
    if (!terms.length) return html;
    var rx = new RegExp('(' + terms.map(reEsc).join('|') + ')', 'gi');
    return html.split(/(<[^>]+>)/).map(function (seg) {
      return seg.charAt(0) === '<' ? seg : seg.replace(rx, '<mark>$1</mark>');
    }).join('');
  }

  function authorName(r) { return r.j === 1 ? ownerName() : (r.au || '?'); }
  function authorColor(r) { return r.j === 1 ? OWNER.color : (r.nc || ''); }

  function blob(r) {
    if (r._s === undefined) {
      var urls = (r.c.match(/https?:\/\/[^\s"'<>]+/g) || []).join(' ');
      var who = r.j === 1 ? (HAS_OWNER_NAME ? ownerName() : '') : (r.au || '');
      r._s = (stripHtml(r.c) + ' ' + urls + ' ' + who + ' '
              + (r.h ? r.h.join(' ') : '')).toLowerCase();
    }
    // when the backup carries no owner name at all, the displayed name is a
    // localised placeholder, so it is appended per call instead of cached
    if (r.j === 1 && !HAS_OWNER_NAME) return r._s + ' ' + ownerName().toLowerCase();
    return r._s;
  }

  // ---- query parsing ----
  // "cat dog -bird" -> terms ['cat','dog'] (all required), negs ['bird'] (excluded)
  function parseQuery(raw) {
    terms = []; negs = [];
    if (!raw) return;
    var parts = raw.split(/\s+/);
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p) continue;
      if (p.charAt(0) === '-') {
        var w = p.slice(1);
        if (w) negs.push(w);
      } else {
        terms.push(p);
      }
    }
  }

  // ---- filtering ----
  function dateOk(r) {
    if (!sel) return true;
    return sel.type === 'year' ? r.t.slice(0, 4) === sel.v : r.t.slice(0, 7) === sel.v;
  }

  function run() {
    parseQuery($q.val().trim().toLowerCase());
    var tag = $tag.val();
    var kinds = $('.fk:checked').map(function () { return this.value; }).get();
    var authors = $('.fa:checked').map(function () { return this.value; }).get();

    var active = terms.length > 0 || negs.length > 0 || sel !== null || tag !== '';
    if (!active) {
      idle = true;
      matched = []; shown = 0;
      $results.html('<div class="empty">' + L().empty_start + '</div>');
      $more.hide();
      $stat.html(L().stat_idle(comma(DATA.length), comma(NP), comma(NR)));
      return;
    }
    idle = false;

    var res = [];
    for (var i = 0; i < DATA.length; i++) {
      var r = DATA[i];
      if (kinds.indexOf(r.k) === -1) continue;
      if (authors.indexOf(String(r.j)) === -1) continue;
      if (!dateOk(r)) continue;
      if (tag && (!r.h || r.h.indexOf(tag) === -1)) continue;
      if (terms.length || negs.length) {
        var s = blob(r), ok = true, t;
        for (t = 0; t < terms.length; t++) {
          if (s.indexOf(terms[t]) === -1) { ok = false; break; }
        }
        if (ok) {
          for (t = 0; t < negs.length; t++) {
            if (s.indexOf(negs[t]) !== -1) { ok = false; break; }
          }
        }
        if (!ok) continue;
      }
      res.push(r);
    }
    matched = res; shown = 0;
    $results.empty();
    if ($rightHolder.length) $rightHolder.scrollTop(0);
    renderMore();
    updateStat();
  }

  // ---- rendering ----
  function itemHtml(r, isResp) {
    var color = authorColor(r);
    var kindLabel = r.k === 'p' ? L().kind_p : L().kind_r;
    var name = '<a target="_blank" href="https://www.plurk.com/p/' + r.b + '" class="name"'
             + (color ? ' style="color:#' + color + '"' : '') + '>' + authorName(r) + '</a>';
    var qual = (r.q && /^[a-z]+$/.test(r.qz))
             ? '<span class="qualifier q_' + r.qz + '">' + r.q + '</span>' : '';
    var who = r.j === 1 ? ''
            : '<span class="kind r" style="background:#444">' + L().badge_others + '</span>';
    var manager = isResp ? '' :
      '<div class="manager"><a target="_blank" href="https://www.plurk.com/p/' + r.b
      + '" class="open-plink"><i class="cmp-outlink"></i><span>' + L().open_plurk(r.b)
      + '</span></a></div>';
    return '<div class="plurk ' + (isResp ? 'response ' : '') + 'clearfix" data-basepid="' + r.b
      + '" data-gi="' + (r._gi != null ? r._gi : '') + '">'
      + '<div class="user"><span class="kind ' + r.k + '">' + kindLabel + '</span>'
      + who + name + qual + '</div>'
      + '<div class="content">' + highlight(r.c) + '</div>'
      + manager
      + '<div class="info"><span class="time">' + r.t + '</span></div></div>';
  }

  function renderMore() {
    if (!matched.length) {
      $results.html('<div class="empty">' + L().empty_none + '</div>');
      $more.hide(); return;
    }
    var end = Math.min(shown + PAGE, matched.length), html = '';
    for (var i = shown; i < end; i++) html += itemHtml(matched[i], false);
    $results.append(html);
    shown = end;
    $more.toggle(shown < matched.length);
    $moreBtn.text(L().more(comma(shown), comma(matched.length)));
  }

  function updateStat() {
    var scope = sel ? L().scope_sel(sel.v) : L().scope_all;
    $stat.html(L().stat_hit(comma(matched.length), scope, comma(DATA.length)));
  }

  // ---- thread popup ----
  function openThread(bid, src) {
    openedThread = { bid: bid, src: src };
    var t = byBase[bid];
    var $ph = $('#popplurk-plurk-holder').empty();
    var $rh = $('#popplurk-responses-holder').empty();
    if (t && t.p) $ph.html(itemHtml(t.p, false));
    else $ph.html('<div class="plurk"><div class="content">' + L().pop_nohead + '</div>'
      + '<div class="manager"><a target="_blank" href="https://www.plurk.com/p/' + bid
      + '" class="open-plink"><i class="cmp-outlink"></i><span>' + L().open_plurk(bid)
      + '</span></a></div></div>');
    var rs = (t ? t.r : []).slice().sort(function (a, b) { return a.t < b.t ? -1 : 1; });
    if (rs.length) {
      var html = '';
      for (var i = 0; i < rs.length; i++) html += itemHtml(rs[i], true);
      $rh.html(html);
    } else {
      $rh.html('<div class="empty" style="padding:24px">' + L().pop_noresp + '</div>');
    }
    $('#pop-title').text(L().pop_title(bid, rs.length));
    $('#popplurk').show();

    // auto-scroll to the clicked response and highlight it
    if (src && src.k === 'r' && src._gi != null) {
      var $hit = $rh.find('.response[data-gi="' + src._gi + '"]');
      if ($hit.length) {
        setTimeout(function () {
          $hit[0].scrollIntoView({ block: 'center' });
          $hit.addClass('hit');
          setTimeout(function () { $hit.removeClass('hit'); }, 2200);
        }, 0);
      }
    } else {
      $rh.scrollTop(0);
    }
  }
  function closePop(id) {
    $('#' + id).hide();
    if (id === 'popplurk') openedThread = null;
  }

  // ---- calendar ----
  function buildCalendar() {
    var ymCount = {}, yCount = {};
    for (var i = 0; i < DATA.length; i++) {
      if (DATA[i].k !== 'p') continue;
      var ym = DATA[i].t.slice(0, 7), y = ym.slice(0, 4);
      ymCount[ym] = (ymCount[ym] || 0) + 1;
      yCount[y] = (yCount[y] || 0) + 1;
    }
    var years = Object.keys(yCount).sort(function (a, b) { return b - a; }), html = '';
    for (var yi = 0; yi < years.length; yi++) {
      var y = years[yi];
      html += '<div class="year-holder"><div class="year" data-year="' + y + '">' + y
            + ' <span style="font-size:12px;font-weight:400;opacity:.7">(' + yCount[y]
            + ')</span></div><div class="month-holder clearfix">';
      var months = [];
      for (var m = 1; m <= 12; m++) {
        var ym = y + '-' + (m < 10 ? '0' : '') + m;
        if (ymCount[ym]) months.push([m, ym, ymCount[ym]]);
      }
      months.sort(function (a, b) { return b[0] - a[0]; });
      for (var mi = 0; mi < months.length; mi++)
        html += '<div class="month" data-ym="' + months[mi][1] + '">' + months[mi][0]
              + '<span class="plurks-count">' + months[mi][2] + '</span></div>';
      html += '</div></div>';
    }
    $('#calendar').html(html);
  }

  function refreshSelHighlight() {
    $('#calendar .current').removeClass('current');
    $('#cal-clear').toggleClass('active', sel === null);
    if (!sel) return;
    if (sel.type === 'year') $('#calendar .year[data-year="' + sel.v + '"]').addClass('current');
    else $('#calendar .month[data-ym="' + sel.v + '"]').addClass('current');
  }

  // ---- language ----
  function buildTagOptions() {
    var keep = $tag.val();
    var opts = '<option value="">' + L().tag_all(TAGS.length) + '</option>';
    for (var k = 0; k < TAGS.length; k++)
      opts += '<option value="' + TAGS[k] + '">' + TAGS[k] + ' (' + TAGCOUNT[TAGS[k]] + ')</option>';
    $tag.html(opts);
    if (keep) $tag.val(keep);
  }

  function buildFooter() {
    $footer.html(L().footer(fmtDate(INFO.backup_date), comma(NP), comma(NR),
                            comma(DATA.length), TAGS.length));
  }

  function buildAcct() {
    $('#acct').html('<img src="' + avatarUrl(U) + '" alt=""><span>' + ownerName()
      + (OWNER.nick ? ' @' + OWNER.nick : '') + '</span>');
  }

  // re-render the results already on screen without changing the result set
  function relayout() {
    if (idle) { run(); return; }
    var keep = shown, top = $rightHolder.scrollTop();
    $results.empty(); shown = 0;
    if (!matched.length) renderMore();
    else while (shown < keep) renderMore();
    updateStat();
    $rightHolder.scrollTop(top);
  }

  function applyLang() {
    var d = L();
    document.documentElement.lang = d.html_lang;
    document.title = d.app_title;
    $('[data-i18n]').each(function () {
      var v = d[$(this).attr('data-i18n')];
      if (typeof v === 'string') $(this).text(v);
    });
    $('[data-i18n-ph]').each(function () {
      var v = d[$(this).attr('data-i18n-ph')];
      if (typeof v === 'string') $(this).attr('placeholder', v);
    });
    buildAcct();
    buildTagOptions();
    buildFooter();
    relayout();
    if (openedThread) openThread(openedThread.bid, openedThread.src);
  }

  function setLang(v) {
    if (!I18N[v] || v === lang) return;
    lang = v;
    try { window.localStorage && window.localStorage.setItem(LANG_KEY, v); } catch (e) { /* ignore */ }
    applyLang();
  }

  // ---- init ----
  $(function () {
    $q = $('#q'); $stat = $('#stat'); $results = $('#results');
    $more = $('#more'); $moreBtn = $('#moreBtn'); $tag = $('#tag');
    $footer = $('#footer'); $rightHolder = $('#right-holder');

    // index: global id, thread map, counts, hashtags
    var tagCount = {};
    for (var i = 0; i < DATA.length; i++) {
      var r = DATA[i];
      r._gi = i;
      if (r.k === 'p') NP++; else NR++;
      if (!byBase[r.b]) byBase[r.b] = { p: null, r: [] };
      if (r.k === 'p') byBase[r.b].p = r; else byBase[r.b].r.push(r);
      var h = r.h;
      if (h) for (var j = 0; j < h.length; j++) tagCount[h[j]] = (tagCount[h[j]] || 0) + 1;
    }
    TAGCOUNT = tagCount;
    TAGS = Object.keys(tagCount).sort(function (a, b) { return tagCount[b] - tagCount[a]; });

    buildCalendar();
    refreshSelHighlight();

    // calendar interaction
    $('#calendar').on('click', '.month', function () {
      var ym = $(this).data('ym') + '';
      sel = (sel && sel.type === 'month' && sel.v === ym) ? null : { type: 'month', v: ym };
      refreshSelHighlight(); run();
    });
    $('#calendar').on('click', '.year', function () {
      var y = $(this).data('year') + '';
      sel = (sel && sel.type === 'year' && sel.v === y) ? null : { type: 'year', v: y };
      refreshSelHighlight(); run();
    });
    $('#cal-clear').on('click', function () { sel = null; refreshSelHighlight(); run(); });

    // search + filters
    var timer;
    $q.on('input', function () { clearTimeout(timer); timer = setTimeout(run, 180); });
    $q.on('keydown', function (e) { if (e.which === 13) { clearTimeout(timer); run(); } });
    $('#go').on('click', run);
    $('#clear').on('click', function () {
      $q.val(''); $tag.val(''); $('.fk,.fa').prop('checked', true);
      sel = null; refreshSelHighlight(); run();
    });
    $('.fk,.fa,#tag').on('change', run);
    $moreBtn.on('click', renderMore);

    // language toggle
    $('#lang').on('click', function () { setLang(lang === 'zh' ? 'en' : 'zh'); });

    // popup: click a result opens its thread (response -> auto-scroll to it)
    $(document).on('click', '#results .plurk', function (e) {
      if ($(e.target).closest('a').length) return;
      var r = DATA[$(this).data('gi')];
      if (r) openThread(r.b + '', r);
    });
    // image lightbox
    $(document).on('click', 'a.pictureservices', function (e) {
      e.preventDefault();
      $('#popimage-img').attr('src', $(this).attr('href'));
      $('#popimage').show();
      return false;
    });
    // close handlers
    $('#popplurk').on('click', '.popwindow-overlay', function () { closePop('popplurk'); });
    $('#pop-close').on('click', function () { closePop('popplurk'); });
    $('#popimage').on('click', '.popwindow-overlay, .popwindow-holder', function () { closePop('popimage'); });
    $(document).on('keydown', function (e) {
      if (e.which === 27) { closePop('popimage'); closePop('popplurk'); }
    });

    applyLang();   // paints identity, labels, tag list, footer and the blank state
  });
})();

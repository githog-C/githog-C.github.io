# -*- coding: utf-8 -*-
"""
Build a full-text search index from a Plurk backup
(the export that contains index.html and a data/ folder).

Usage:
  1. Unzip your Plurk backup.
  2. Put this file in the backup root (next to index.html and the data/ folder),
     together with search.html and the static/ files from this template.
  3. Run:  python build_index.py
  4. Open  search.html  in a browser.

Output: search-data.js (a single index file the search page loads).
Only the Python standard library is used - no extra packages required.
"""
import os, re, json, glob, sys
import email.utils as eu

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")

if not os.path.isdir(DATA):
    sys.exit("[error] data/ not found. Put this script in the backup root "
             "(next to index.html and the data/ folder).")


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def parse_assign(text):
    """Strip a 'BackupData.xxx[...] = <json>;' wrapper and return the JSON value."""
    body = text[text.find("=") + 1:].strip()
    if body.endswith(";"):
        body = body[:-1].strip()
    return json.loads(body)


def fixhtml(s):
    s = s.replace("<a ", '<a target="_blank" ')
    s = s.replace('src="/static/emoticons/', 'src="https://www.plurk.com/static/emoticons/')
    return s


def ts(s):
    try:
        return eu.parsedate_to_datetime(s).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return s


def tags(html):
    # only the hashtags Plurk actually marked up in the original post
    return list(dict.fromkeys(re.findall(r'<span class="hashtag">(#[^<]+)</span>', html or "")))


# owner identity (used to flag the owner's own responses)
user = parse_assign(read(os.path.join(DATA, "user.js")))
owner_id = user.get("id")

recs = []

# ---- the owner's own plurks ----
for fp in sorted(glob.glob(os.path.join(DATA, "plurks", "*.js"))):
    for p in parse_assign(read(fp)):
        recs.append({
            "k": "p",
            "b": p["base_id"],
            "t": ts(p["posted"]),
            "q": p.get("translate_qualifier") or "",
            "qz": p.get("qualifier") or "",
            "j": 1,                                   # 1 = owner
            "c": fixhtml(p.get("content", "")),
            "h": tags(p.get("content", "")),
            "rc": p.get("response_count", 0),
        })

# ---- responses ----
for fp in sorted(glob.glob(os.path.join(DATA, "responses", "*.js"))):
    txt = read(fp)
    m = re.match(r'^BackupData\.responses\["([^"]+)"\]=', txt)
    if not m:
        continue
    bid = m.group(1)
    for r in parse_assign(txt):
        u = r.get("user", {})
        is_owner = 1 if u.get("id") == owner_id else 0
        rec = {
            "k": "r",
            "b": bid,
            "t": ts(r["posted"]),
            "q": r.get("translate_qualifier") or "",
            "qz": r.get("qualifier") or "",
            "j": is_owner,
            "c": fixhtml(r.get("content", "")),
            "h": tags(r.get("content", "")),
        }
        if not is_owner:                              # keep other users' name + colour
            rec["au"] = u.get("display_name") or u.get("nick_name") or "?"
            nc = u.get("name_color")
            if nc:
                rec["nc"] = nc
        recs.append(rec)

recs.sort(key=lambda x: x["t"], reverse=True)

out = os.path.join(ROOT, "search-data.js")
with open(out, "w", encoding="utf-8") as f:
    f.write("window.SEARCH_DATA=")
    json.dump(recs, f, ensure_ascii=False, separators=(",", ":"))
    f.write(";")

np = sum(1 for r in recs if r["k"] == "p")
nr = len(recs) - np
print("Done. %d records (plurks %d, responses %d) -> %s"
      % (len(recs), np, nr, os.path.basename(out)))
print("Now open search.html in a browser.")

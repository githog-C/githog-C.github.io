#!/bin/bash
# macOS 雙擊啟動檔：產生 search-data.js
# 首次若無法雙擊執行，請先在終端機執行一次： chmod +x build_index.command
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  python3 build_index.py
else
  python build_index.py
fi
echo ""
echo "完成。請用瀏覽器開啟 search.html。"
read -n 1 -s -r -p "按任意鍵結束..."
echo ""

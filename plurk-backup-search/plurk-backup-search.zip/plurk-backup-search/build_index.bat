@echo off
chcp 65001 >nul
rem Windows 雙擊啟動檔：產生 search-data.js
cd /d "%~dp0"
where python >nul 2>nul && (python build_index.py) || (py build_index.py)
echo.
echo 完成。請用瀏覽器開啟 search.html。
pause

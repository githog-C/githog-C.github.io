# Plurk 備份全文檢索

把 Plurk 個人備份（解壓縮後內含 `index.html` 與 `data/` 目錄的那種）變成可離線全文檢索的網頁。

## 需求

- 一份解壓縮後的 Plurk 備份資料夾（內含 `index.html` 與 `data/` 目錄）。
- 已安裝 Python 3（僅使用標準函式庫，不需安裝任何額外套件）。
- 任一瀏覽器。

## 安裝

把範本檔案**全部複製到備份資料夾的根目錄**（與 `index.html`、`data/` 同一層）：

- `build_index.py`
- `build_index.command` （macOS 點兩下啟動）
- `build_index.bat` （Windows 點兩下啟動）
- `search.html`
- `search.css`
- `search.js`

（備份原有的 `static/` 資料夾請保留，裡面的 `backup.css`、`jquery-*.js`、`icons.png` 會被沿用。請勿把上面這些檔放進 `static/`。）

## 產生索引（兩種方式擇一）

### 方式 A：點兩下啟動
- Windows： `build_index.bat`
- macOS： `build_index.command`
  - 首次若無法執行，請先在終端機跑一次：`chmod +x build_index.command`，之後即可啟動。

### 方式 B：終端機
**重要：`build_index.py` 必須用終端機執行；直接點擊開啟 `.py` 只會用編輯器打開，不會產生索引。**
- Windows：`python build_index.py`
- macOS / Linux：`python3 build_index.py`
  （macOS 通常沒有 `python` 指令，只有 `python3`。）

執行成功後會產生 `search-data.js`。

## 開啟

用瀏覽器開啟 `search.html`。

> 備份內容較多時，`search-data.js` 可能達數十 MB；首次開啟頁面需數秒讀取屬正常情況。

## 功能

- 多詞 AND 全文檢索（以空白分隔），命中關鍵字會有明顯標示。
- 排除語法：關鍵字前加半形 `-` 表示「不含」，可與 AND 混用。
  - `貓 狗` ── 同時含「貓」與「狗」。
  - `貓 -狗` ── 含「貓」但不含「狗」。
  - `貓 狗 -醫院 -結紮` ── 含「貓」與「狗」，且不含「醫院」與「結紮」。
  - `-` 只在字首才視為排除，因此 `e-mail`、`Coca-Cola` 這類字仍可正常搜尋。
  - 只下排除條件（如單獨輸入 `-廣告`）也可執行，通常搭配年月或 hashtag 篩選使用。
- 篩選：噗首 / 回應、本人 / 他人、年月（左欄）、hashtag。
- 介面中英切換：右上角按鈕（`EN` ↔ `中文`），選擇會記在瀏覽器中，下次開啟沿用。
  - 只翻譯介面，備份讀入的噗文原文一律照原樣顯示，不做任何翻譯或改寫。
  - 英文用語依 Plurk 官方英文說明（<https://www.plurk.com/help/en/plurk>、`/help/en/timeline`）：
    噗首為 **plurk**、回應為 **reply**、標籤為 **hashtag**。
- 點任一結果可跳出該則所在的整串（噗首 + 全部回應）；點回應會自動捲動到該則並標示。
- 點縮圖可放大檢視。
- 深色模式介面，單一視窗版面。
- 表情符號與圖片需有網路才會顯示，純文字檢索離線即可用。

## 運作方式

- 帳號身分（顯示名稱、名稱顏色、頭貼）與備份日期、各項則數，皆由程式於開啟時自動讀取備份內既有的 `data/user.js` 與 `data/info.js`，無需手動設定，因此適用於任何人的 Plurk 備份。
- `build_index.py` 會掃描 `data/plurks/` 與 `data/responses/`，彙整成單一索引檔 `search-data.js`；hashtag 只採計原文中正式標記為 hashtag 的詞。
- 若日後備份有更新，重新執行一次索引產生步驟即可重建。

## 檔案清單

```
build_index.py        產生索引的腳本（標準函式庫）
build_index.command   macOS 點兩下啟動
build_index.bat       Windows 點兩下啟動
search.html           檢索頁入口
search.css            深色介面樣式
search.js             檢索與介面邏輯
README.md             本說明檔案
```
（以上檔案全部放在備份根目錄，與 `index.html`、`data/`、`static/` 同一層。）

---

本工具為非官方的個人輔助小工具，資料與服務皆來自 Plurk。
